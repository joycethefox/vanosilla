﻿using System.Collections.Generic;

namespace TranslationServer.Loader
{
    public class BannedNamesConfiguration
    {
        public List<string> BannedNames { get; set; }
    }
}