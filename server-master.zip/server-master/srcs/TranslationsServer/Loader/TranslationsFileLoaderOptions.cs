﻿namespace TranslationServer.Loader
{
    public class TranslationsFileLoaderOptions
    {
        public string TranslationsPath { get; set; }
    }
}