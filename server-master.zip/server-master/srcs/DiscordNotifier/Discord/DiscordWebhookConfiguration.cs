using System.Collections.Generic;

namespace DiscordNotifier.Discord
{
    public class DiscordWebhookConfiguration : Dictionary<LogType, string>
    {
    }
}