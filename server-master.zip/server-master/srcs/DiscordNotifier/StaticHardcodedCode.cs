﻿namespace DiscordNotifier
{
    public static class StaticHardcodedCode
    {
        public const string AvatarUrl = "https://avatars0.githubusercontent.com/u/40839221?s=200";
    }
}