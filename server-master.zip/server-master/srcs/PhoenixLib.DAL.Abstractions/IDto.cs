﻿// WingsEmu
// 
// Developed by NosWings Team

namespace PhoenixLib.DAL
{
    /// <summary>
    ///     A simple DTO
    /// </summary>
    public interface IDto
    {
    }
}