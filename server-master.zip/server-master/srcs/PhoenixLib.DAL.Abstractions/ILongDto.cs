﻿// WingsEmu
// 
// Developed by NosWings Team

namespace PhoenixLib.DAL
{
    /// <summary>
    /// </summary>
    public interface ILongDto : IDto
    {
        long Id { get; set; }
    }
}