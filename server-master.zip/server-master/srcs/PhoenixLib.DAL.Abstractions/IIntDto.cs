namespace PhoenixLib.DAL
{
    /// <summary>
    /// </summary>
    public interface IIntDto : IDto
    {
        int Id { get; set; }
    }
}