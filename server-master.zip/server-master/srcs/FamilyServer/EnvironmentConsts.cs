﻿namespace FamilyServer
{
    public static class EnvironmentConsts
    {
        public const string FamilyServerSaveIntervalMinutes = "FAMILY_SERVER_SAVE_INTERVAL_MINUTES";
    }
}