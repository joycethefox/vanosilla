﻿// WingsEmu
// 
// Developed by NosWings Team

namespace PhoenixLib.Events
{
    /// <summary>
    ///     Interface for every type of event notification
    /// </summary>
    public interface IAsyncEvent
    {
    }
}