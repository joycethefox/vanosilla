namespace PhoenixLib.Events
{
    public interface IEvent
    {
    }
}