namespace PhoenixLib.Scheduler
{
    /// <summary>
    ///     Default JobPool
    /// </summary>
    public interface IScheduledJob : IGenericJobPool<string>
    {
    }
}