namespace PhoenixLib.Scheduler
{
    /// <summary>
    ///     Cron pools
    /// </summary>
    public interface ICronJobPool : IGenericCronPool<string>
    {
    }
}