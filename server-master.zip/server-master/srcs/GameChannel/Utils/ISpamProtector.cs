﻿// WingsEmu
// 
// Developed by NosWings Team

namespace GameChannel.Utils
{
    public interface ISpamProtector
    {
        bool CanConnect(string ipAddress);
    }
}