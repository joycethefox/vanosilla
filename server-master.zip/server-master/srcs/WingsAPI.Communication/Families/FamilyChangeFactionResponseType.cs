﻿namespace WingsAPI.Communication.Families
{
    public enum FamilyChangeFactionResponseType
    {
        GENERIC_ERROR,
        ALREADY_THAT_FACTION,
        UNDER_COOLDOWN,
        SUCCESS
    }
}