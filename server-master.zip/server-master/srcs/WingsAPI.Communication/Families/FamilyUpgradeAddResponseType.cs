namespace WingsAPI.Communication.Families
{
    public enum FamilyUpgradeAddResponseType
    {
        UNKNOWN_ERROR,
        SUCCESS,
        GENERIC_SERVER_ERROR,
        MAINTENANCE_MODE,
        UPGRADE_ALREADY_UNLOCKED
    }
}