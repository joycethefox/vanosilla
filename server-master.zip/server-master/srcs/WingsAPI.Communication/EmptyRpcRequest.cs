using ProtoBuf;

namespace WingsAPI.Communication
{
    [ProtoContract]
    public class EmptyRpcRequest
    {
    }
}