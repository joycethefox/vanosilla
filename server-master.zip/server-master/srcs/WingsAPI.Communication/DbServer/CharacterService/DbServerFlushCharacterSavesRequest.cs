﻿using ProtoBuf;

namespace WingsAPI.Communication.DbServer.CharacterService
{
    [ProtoContract]
    public class DbServerFlushCharacterSavesRequest
    {
    }
}