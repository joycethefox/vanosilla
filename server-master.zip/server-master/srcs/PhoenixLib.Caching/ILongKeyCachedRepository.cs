namespace PhoenixLib.Caching
{
    public interface ILongKeyCachedRepository<T> : ICachedRepository<long, T>
    {
    }
}