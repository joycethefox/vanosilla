namespace PhoenixLib.DAL.EFCore.PGSQL
{
    public interface IStringKeyEntity
    {
        public string Id { get; set; }
    }
}