namespace PhoenixLib.DAL.EFCore.PGSQL
{
    public interface IIntEntity : IIntDto
    {
    }
}