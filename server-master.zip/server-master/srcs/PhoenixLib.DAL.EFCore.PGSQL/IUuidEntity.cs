﻿namespace PhoenixLib.DAL.EFCore.PGSQL
{
    /// <summary>
    ///     An entity that has a GUID as ID
    /// </summary>
    public interface IUuidEntity : IUuidDto
    {
    }
}