﻿// WingsEmu
// 
// Developed by NosWings Team

namespace PhoenixLib.DAL.EFCore.PGSQL
{
    /// <summary>
    ///     An entity that has a long as ID
    /// </summary>
    public interface ILongEntity : ILongDto
    {
    }
}