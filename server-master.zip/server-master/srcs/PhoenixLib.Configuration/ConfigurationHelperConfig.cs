﻿namespace PhoenixLib.Configuration
{
    public class ConfigurationHelperConfig
    {
        public string ConfigurationDirectory { get; set; } = "config/";
    }
}