﻿using PhoenixLib.Events;

namespace WingsEmu.ClusterScheduler.Ranking
{
    public class RankingRefreshEvent : IAsyncEvent
    {
    }
}