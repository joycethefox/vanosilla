// WingsEmu
// 
// Developed by NosWings Team

namespace WingsEmu.ClusterScheduler.Configs
{
    public class InstantBattleStartFileConfiguration
    {
        public string CronExpression { get; set; }
    }
}