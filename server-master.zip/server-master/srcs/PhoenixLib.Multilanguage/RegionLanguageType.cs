﻿// WingsEmu
// 
// Developed by NosWings Team

namespace PhoenixLib.MultiLanguage
{
    public enum RegionLanguageType
    {
        EN = 0,
        DE = 1,
        FR = 2,
        IT = 3,
        PL = 4,
        ES = 5,
        CZ = 6,
        RU = 7,
        TR = 8
    }
}