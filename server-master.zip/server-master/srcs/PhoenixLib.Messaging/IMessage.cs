// WingsEmu
// 
// Developed by NosWings Team

namespace PhoenixLib.ServiceBus
{
    public interface IMessage
    {
    }
}