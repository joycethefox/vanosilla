using System;

namespace PhoenixLib.ServiceBus
{
    public interface IServiceBusInstance
    {
        Guid Id { get; }
    }
}