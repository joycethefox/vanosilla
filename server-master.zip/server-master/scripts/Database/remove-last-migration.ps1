# comment
dotnet ef migrations remove --project .\srcs\_plugins\Plugin.DB.EF --startup-project .\srcs\_plugins\Plugin.DB.EF
