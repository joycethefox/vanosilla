# comment
dotnet ef database update $Args[0] --project .\srcs\_plugins\Plugin.DB.EF --startup-project .\srcs\_plugins\Plugin.DB.EF