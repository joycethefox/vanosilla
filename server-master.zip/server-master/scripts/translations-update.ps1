$wingsemu_translations_directory = "../server-translations"

./dist/toolkit/Toolkit.exe translations -i $wingsemu_translations_directory -o $wingsemu_translations_directory